#!/usr/bin/env node
/**
 * Next Shift Hockey — portal build.
 *
 *   node scripts/build.js
 *
 * Reads data/rubric.json and every data/players/*.json, validates them,
 * runs the scorer-drift check, and writes p/<token>/index.html per player.
 * No dependencies. Node 18+.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = path.join(__dirname, '..');
const PLAYER_DIR = path.join(ROOT, 'data', 'players');
const OUT_DIR = path.join(ROOT, 'p');

const rubric = JSON.parse(fs.readFileSync(path.join(ROOT, 'data', 'rubric.json'), 'utf8'));
const TEMPLATE = fs.readFileSync(path.join(ROOT, 'templates', 'portal.html'), 'utf8');

const METRICS = {};
for (const cat of rubric.categories) {
  for (const m of cat.metrics) METRICS[m.id] = { ...m, category: cat.name };
}

const problems = [];
const warnings = [];

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// ---------------------------------------------------------------- validation

function validate(player, file) {
  const id = player.player_id || file;

  for (const ev of player.scoring_events || []) {
    const where = `${id} / ${ev.window} / ${ev.scorer_id}`;

    if (!ev.scorer_id) problems.push(`${where}: scoring event has no scorer_id.`);
    if (!ev.scored_on) problems.push(`${where}: scoring event has no scored_on date.`);

    for (const [metricId, value] of Object.entries(ev.metrics || {})) {
      if (!METRICS[metricId]) {
        problems.push(`${where}: "${metricId}" is not a metric in the rubric.`);
        continue;
      }
      if (value === 'NS') {
        if (!ev.evidence?.[metricId]) {
          problems.push(`${where}: ${metricId} is NS with no note saying why it couldn't be scored.`);
        }
        continue;
      }
      if (!Number.isInteger(value) || value < rubric.scale.min || value > rubric.scale.max) {
        problems.push(`${where}: ${metricId} is ${JSON.stringify(value)} — must be 1-5 or "NS".`);
        continue;
      }
      if (rubric.evidence_required_at.includes(value) && !ev.evidence?.[metricId]) {
        problems.push(`${where}: ${metricId} scored ${value} with no evidence note. Extremes require one.`);
      }
    }

    const missing = Object.keys(METRICS).filter((m) => !(m in (ev.metrics || {})));
    if (missing.length) warnings.push(`${where}: ${missing.length} metric(s) not filled in — ${missing.join(', ')}`);
  }
}

// -------------------------------------------------------- calibration check

function calibration(player) {
  const byWindow = {};
  for (const ev of player.scoring_events || []) {
    (byWindow[ev.window] ||= []).push(ev);
  }
  for (const [win, events] of Object.entries(byWindow)) {
    if (events.length < 2) continue;
    for (const metricId of Object.keys(METRICS)) {
      const scored = events
        .filter((e) => typeof e.metrics?.[metricId] === 'number')
        .map((e) => ({ scorer: e.scorer_id, v: e.metrics[metricId] }));
      if (scored.length < 2) continue;
      const vals = scored.map((s) => s.v);
      const spread = Math.max(...vals) - Math.min(...vals);
      if (spread > rubric.calibration.max_scorer_spread) {
        problems.push(
          `DRIFT — ${player.player_id} / ${win} / ${METRICS[metricId].name}: ` +
          scored.map((s) => `${s.scorer}=${s.v}`).join(', ') +
          ` (spread ${spread}). Rewrite the anchor. Do not average.`
        );
      }
    }
  }
}

// ------------------------------------------------------------------ render

function track(value) {
  if (value === 'NS' || value == null) {
    return `<div class="track">${'<i class="notch ns"></i>'.repeat(5)}</div>`;
  }
  let out = '';
  for (let i = 1; i <= 5; i++) {
    out += i < value ? '<i class="notch on"></i>'
         : i === value ? '<i class="notch tip"></i>'
         : '<i class="notch"></i>';
  }
  return `<div class="track">${out}</div>`;
}

function deltaCell(current, baseline) {
  if (current === 'NS' || current == null) return `<div class="delta">NS</div>`;
  if (baseline == null || baseline === 'NS') return `<div class="delta">&mdash;</div>`;
  const d = current - baseline;
  if (d === 0) return `<div class="delta">0</div>`;
  return `<div class="delta${d > 0 ? ' up' : ''}">${d > 0 ? '+' : ''}${d}</div>`;
}

function scoreBody(latest, baseline) {
  if (!latest) {
    return `<p class="empty">No baseline scored yet. This page fills in the day the first evaluation is published.</p>`;
  }
  let html = '';
  for (const cat of rubric.categories) {
    html += `<div class="cat"><h4>${esc(cat.name)}</h4>`;
    for (const m of cat.metrics) {
      const v = latest.metrics?.[m.id] ?? null;
      const b = baseline ? baseline.metrics?.[m.id] ?? null : null;
      html += `<div class="row"><div class="label">${esc(m.name)}</div>${track(v)}${deltaCell(v, b)}</div>`;
      const note = latest.evidence?.[m.id];
      if (note) html += `<p class="evidence">${esc(note)}</p>`;
    }
    html += `</div>`;
  }
  return html;
}

function renderIdp(idp) {
  if (!idp?.objectives?.length) return `<p class="empty">Development plan is published within 48 hours of the baseline evaluation.</p>`;
  const range = idp.block_start ? `<p class="cap">${esc(idp.block_start)} to ${esc(idp.block_end || '')}</p>` : '';
  return range + `<ol>${idp.objectives.map((o) => `<li>${esc(o)}</li>`).join('')}</ol>`;
}

function renderWeekly(w) {
  if (!w) return `<p class="empty">Your weekly plan is posted every Monday morning.</p>`;
  const rows = [
    ['Week of', w.week_of], ['On ice', w.hockey_objective], ['Practice', w.practice_challenge],
    ['Game KPI', w.game_kpi], ['Film', w.video_assignment], ['Off ice', w.off_ice], ['School', w.academic],
  ].filter(([, v]) => v);
  return `<dl class="kv">${rows.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('')}</dl>`;
}

function renderProfile(p) {
  const rows = [
    ['Class of', p.grad_year], ['Position', p.position], ['Shot', p.shot],
    ['Size', [p.height, p.weight && `${p.weight} lb`].filter(Boolean).join(', ')],
    ['Team', p.team], ['League', p.league], ['School', p.school],
    ['Program', p.tier && p.tier[0].toUpperCase() + p.tier.slice(1)],
  ].filter(([, v]) => v);
  return `<dl class="kv">${rows.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('')}</dl>`;
}

function renderVideo(list) {
  if (!list?.length) return `<p class="empty">Film reviews appear here as they're published.</p>`;
  return `<table><thead><tr><th>Date</th><th>Review</th><th>Focus</th></tr></thead><tbody>` +
    list.map((v) => `<tr><td>${esc(v.date)}</td><td>${v.url
      ? `<a href="${esc(v.url)}">${esc(v.title)}</a>` : esc(v.title)}</td><td>${(v.tags || [])
      .map((t) => esc(METRICS[t]?.name || t)).join(', ')}</td></tr>`).join('') +
    `</tbody></table>`;
}

function renderPathway(list) {
  if (!list?.length) return `<p class="empty">Target programs are added once the baseline is in and the plan is set.</p>`;
  return `<table><thead><tr><th>Program</th><th>Level</th><th>Status</th><th>Next</th></tr></thead><tbody>` +
    list.map((r) => `<tr><td>${esc(r.program)}</td><td>${esc(r.level)}</td><td>${esc(r.interest)}</td><td>${esc(r.next_action)}</td></tr>`).join('') +
    `</tbody></table>`;
}

// -------------------------------------------------------------------- main

fs.mkdirSync(OUT_DIR, { recursive: true });
const files = fs.readdirSync(PLAYER_DIR).filter((f) => f.endsWith('.json'));
let built = 0;

for (const file of files) {
  const full = path.join(PLAYER_DIR, file);
  const player = JSON.parse(fs.readFileSync(full, 'utf8'));

  // Mint a portal token on first build and write it back to the record.
  if (!player.portal_token) {
    player.portal_token = crypto.randomBytes(16).toString('hex');
    fs.writeFileSync(full, JSON.stringify(player, null, 2) + '\n');
    console.log(`Minted portal token for ${player.player_id}: /p/${player.portal_token}/`);
  }

  validate(player, file);
  calibration(player);

  const events = [...(player.scoring_events || [])].sort((a, b) => a.window.localeCompare(b.window));
  const baseline = events[0] || null;
  const latest = events[events.length - 1] || null;
  const isDelta = latest && baseline && latest !== baseline;

  const html = TEMPLATE
    .replaceAll('{{PLAYER_NAME}}', esc(player.profile?.name || player.player_id))
    .replaceAll('{{PLAYER_SUB}}', esc([player.profile?.team, player.profile?.grad_year && `Class of ${player.profile.grad_year}`]
      .filter(Boolean).join(' — ')))
    .replaceAll('{{SHEET_TITLE}}', isDelta ? 'Evaluation — movement since baseline' : 'Evaluation')
    .replaceAll('{{SHEET_META}}', esc(latest
      ? (isDelta ? `${baseline.label || baseline.window} to ${latest.label || latest.window}`
                 : latest.label || latest.window)
      : 'Not yet scored'))
    .replaceAll('{{SCORE_BODY}}', scoreBody(latest, isDelta ? baseline : null))
    .replaceAll('{{IDP}}', renderIdp(player.idp))
    .replaceAll('{{WEEKLY}}', renderWeekly(player.weekly))
    .replaceAll('{{PROFILE}}', renderProfile(player.profile || {}))
    .replaceAll('{{VIDEO}}', renderVideo(player.video))
    .replaceAll('{{PATHWAY}}', renderPathway(player.pathway));

  const dir = path.join(OUT_DIR, player.portal_token);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'index.html'), html);
  built++;
  console.log(`Built ${player.player_id} -> /p/${player.portal_token}/`);
}

if (warnings.length) {
  console.log('\nIncomplete:');
  warnings.forEach((w) => console.log('  ' + w));
}

if (problems.length) {
  console.error('\nBuild failed:');
  problems.forEach((p) => console.error('  ' + p));
  process.exit(1);
}

console.log(`\n${built} portal page(s) built clean.`);
